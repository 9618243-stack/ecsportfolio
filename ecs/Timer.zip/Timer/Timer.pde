// Lucy Kleven | March 25, 2026 | Timer //<>//
Button btnStart, btnStop, btnReset;

int startTime, elapsedMs, savedTime;
boolean running = false;

void setup() {
  size(500, 500);
  // Initializing your buttons with the positions from your original code
  btnStart = new Button(83, 350, 100, 30, "Start");
  btnStop = new Button(width/2, 350, 100, 30, "Stop");
  btnReset = new Button(417, 350, 100, 30, "Reset");
}

void draw() {
  background(127);

  // Calculate total elapsed time in milliseconds
  if (running) {
    elapsedMs = (millis() - startTime) + savedTime;
  } else {
    elapsedMs = savedTime;
  }

  // Draw the buttons from Tab 2
  btnStart.display();
  btnStop.display();
  btnReset.display();

  // Breakdown the time
  int ms        = (elapsedMs % 1000) / 10; // Get 2-digit milliseconds (00-99)
  int totalSecs = elapsedMs / 1000;
  int s         = totalSecs % 60;
  int m         = (totalSecs / 60) % 60;

  // Format the string as MM:SS:ms
  String timeStr = nf(m, 2) + ":" + nf(s, 2) + ":" + nf(ms, 2);

  // Display the timer
  textSize(80);
  textAlign(CENTER, CENTER);
  fill(250, 0, 0); // Red color from your original request
  text(timeStr, width/2, height/2 - 50);
}

void mousePressed() {
  // Check button clicks using the isMouseOver method from Tab 2
  if (btnStart.isMouseOver()) {
    if (!running) {
      startTime = millis();
      running = true;
    }
  } else if (btnStop.isMouseOver()) {
    if (running) {
      savedTime = elapsedMs;
      running = false;
    }
  } else if (btnReset.isMouseOver()) {
    running = false;
    savedTime = 0;
    elapsedMs = 0;
    startTime = millis(); // Reset reference point
  }
}
