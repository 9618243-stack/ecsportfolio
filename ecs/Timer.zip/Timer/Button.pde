class Button {
  int y, x, w, h;
  String label;

  Button(int x, int y, int w, int h, String label) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.label = label;
  }

  void display() {
    rectMode(CENTER);
    // Visual feedback: Pink when hovering, Blue when not
    if (isMouseOver()) {
      fill(#FFB6C1);
    } else {
      fill(#ADD8E6);
    }

    stroke(0);
    rect(x, y, w, h, 5); // Added a small corner radius of 5

    fill(50);
    textAlign(CENTER, CENTER);
    textSize(22);
    text(label, x, y);
  }

  boolean isMouseOver() {
    return mouseX > x - w/2 && mouseX < x + w/2 &&
      mouseY > y - h/2 && mouseY < y + h/2;
  }
}
